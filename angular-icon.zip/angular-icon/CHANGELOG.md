* 1.1.2
- Add source files to fix warnings after build

* 1.1.1
- Fixed attribute bug

* 1.1.0
- Add AOT compatable build
- Code simplification
- Change host bindings names to follow ng2 standard
