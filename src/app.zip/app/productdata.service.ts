import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { product } from './product/productmodel';
@Injectable()
export class ProductdataService {
public url:string="http://localhost:3000/product/";
  constructor(public _http:HttpClient) { }
getAllProduct(){
  return this._http.get<product>(this.url);
}
deleteProduct(id:number){
  return this._http.delete(this.url+id,{headers:new HttpHeaders().set('Content-Type','application/json')});
}
}
