export class order{
    public constructor(public order_id:number,public date:string,public qty:number,
        public email_id:string,public pro_id:number){

    }
}
