import { Routes,RouterModule } from '@angular/router';
import { ProductComponent } from './product/product.component';
import { UserComponent } from './user/user.component';
import { LoginComponent } from './login/login.component';

const router:Routes=[
    {path:'',redirectTo:'/login',pathMatch:'full'},
    {path:'user',component:UserComponent},
    {path:'products',component:ProductComponent},
    {path:'login',component:LoginComponent}
];

export const routing=RouterModule.forRoot(router);

