import { Component, OnInit } from '@angular/core';
import { user } from '../user/usermodel';
import { LogindataService } from '../logindata.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
email_id:string;
password:string;

  constructor(public data:LogindataService) { }

  ngOnInit() {
  }
  onLogin(){
    let item=new user(this.email_id,this.password,'','','','','','');
    this.data.login(item).subscribe(
      (data:user[])=>{
        console.log(data);
        
        if(data.length==1)
        {
          alert("thayu");
        }
        else{
          alert("na thayu");
        }
      }
    );
  }

}
