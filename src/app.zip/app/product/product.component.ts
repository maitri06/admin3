import { Component, OnInit } from '@angular/core';
import { ProductdataService } from '../productdata.service';
import { product } from './productmodel';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  public product:product[]=[];
  constructor(public _data:ProductdataService) { }

  ngOnInit() {
    this._data.getAllProduct().subscribe(
      (data:any)=>{this.product=data}
    )
  }
  onDeleteProduct(item){
    this._data.deleteProduct(item.pro_id).subscribe(
      (data:any)=>{
        console.log(data);
        this.product.splice(this.product.indexOf(item),1);
      }
    )
  }


}
