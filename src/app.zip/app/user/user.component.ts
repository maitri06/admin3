import { Component, OnInit } from '@angular/core';
import { UserdataService } from "../userdata.service";
import { user } from './usermodel';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
public user:user[]=[];
  constructor(public _data:UserdataService) { }

  ngOnInit() {
    this._data.getAllUsers().subscribe(
      (data:any)=>{
        this.user=data;
      }
    )
  }
  onDeleteUser(item){
    this._data.deleteUser(item.email_id).subscribe(
      (data:any)=>{
        console.log(data);
        this.user.splice(this.user.indexOf(item),1);
      }
    )
  }

}
