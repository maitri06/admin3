export class user{
public constructor(public email_id:string,public password:string,public name:string,
public gender:string,public img:string,public mobile_no:string,public address:string,
public type:string ){ }
}
