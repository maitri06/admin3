import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { routing } from './app.routing';

import { UserdataService } from './userdata.service';
import { ProductdataService } from './productdata.service';
import { OrderdataService } from './orderdata.service';
import { LogindataService } from './logindata.service';

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { ProductComponent } from './product/product.component';
import { OrderComponent } from './order/order.component';
import { HeaderComponent } from './header/header.component';
import { AdduserComponent } from './adduser/adduser.component';
import { LoginComponent } from './login/login.component';


@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    ProductComponent,
    OrderComponent,
    HeaderComponent,
    AdduserComponent,
    LoginComponent
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    routing
  ],
  providers: [UserdataService,ProductdataService,OrderdataService,LogindataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
