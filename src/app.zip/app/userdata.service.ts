import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { user } from './user/usermodel';
@Injectable()
export class UserdataService {
public url:string="http://localhost:3000/user/";
  constructor(public _http:HttpClient) { }
  getAllUsers(){
    return this._http.get<user>(this.url);
  }
  deleteUser(id:string){
    return this._http.delete(this.url+id,{headers:new HttpHeaders().set('Content-Type','application/json')});
  }
}
