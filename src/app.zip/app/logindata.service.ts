import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
//import { order } from "./order/l";

@Injectable()
export class LogindataService {
  public url:string="http://localhost:3000/login";

  constructor(public _http:HttpClient) { }
  login(item){
    let body=JSON.stringify(item);
    return this._http.post(
      this.url,body,{headers:new HttpHeaders().set('Content-Type','application/json')}
    );
  }
 
}
